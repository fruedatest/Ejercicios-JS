var nombre = prompt("Introduce tu nombre");
alert('Hola '+nombre);